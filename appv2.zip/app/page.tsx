"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

type Competition = {
  id: number;
  title: string;
  organizer: string;
  category: string;
  level: string;
  format: string;
  fee: number;
  deadline: string;
  eligibility: string;
  summary: string;
  posterUrl: string | null;
  sourceUrl: string | null;
  isVerified: boolean;
  featured: boolean;
};

type OpportunityRowProps = {
  competition: Competition;
  todayString: string | null;
  expanded: boolean;
  onToggle: () => void;
};

// ============================================================
// 1. DATA DEMO
// Ganti data ini dengan data kompetisi yang sudah diperiksa.
// ============================================================

const competitions: Competition[] = [
  {
    id: 1,
    title: "Hackathon Nasional Gemastik 2026",
    organizer: "Puspresnas / BPTI",
    category: "Teknologi",
    level: "Nasional",
    format: "Tim",
    fee: 0,
    deadline: "2026-11-12",
    eligibility: "Mahasiswa aktif",
    summary:
      "Kompetisi pengembangan solusi teknologi untuk mahasiswa. Periksa panduan resmi untuk mengetahui bidang dan persyaratan pendaftaran.",
    posterUrl: null,
    sourceUrl: null,
    isVerified: false,
    featured: true,
  },
  {
    id: 2,
    title: "National Business Plan Competition",
    organizer: "Universitas Indonesia",
    category: "Bisnis",
    level: "Nasional",
    format: "Tim",
    fee: 0,
    deadline: "2026-11-15",
    eligibility: "Mahasiswa aktif",
    summary:
      "Kompetisi penyusunan rencana bisnis untuk mengembangkan ide dan model usaha.",
    posterUrl: null,
    sourceUrl: null,
    isVerified: false,
    featured: false,
  },
  {
    id: 3,
    title: "UI/UX Design Challenge Nusantara",
    organizer: "Tech Startup JKT",
    category: "Desain",
    level: "Nasional",
    format: "Individu / Tim",
    fee: 50000,
    deadline: "2026-11-18",
    eligibility: "Mahasiswa dan umum",
    summary:
      "Kompetisi desain antarmuka dan pengalaman pengguna dalam pengembangan produk digital.",
    posterUrl: null,
    sourceUrl: null,
    isVerified: false,
    featured: false,
  },
  {
    id: 4,
    title: "Lomba Esai Mahasiswa Nasional",
    organizer: "Kementerian Pendidikan",
    category: "Karya Tulis",
    level: "Nasional",
    format: "Individu",
    fee: 0,
    deadline: "2026-11-20",
    eligibility: "Mahasiswa aktif",
    summary:
      "Kompetisi penulisan esai dengan tema dan ketentuan sesuai panduan penyelenggara.",
    posterUrl: null,
    sourceUrl: null,
    isVerified: false,
    featured: false,
  },
  {
    id: 5,
    title: "Olimpiade Sains dan Teknologi Terapan",
    organizer: "Institut Teknologi Bandung",
    category: "Sains",
    level: "Nasional",
    format: "Individu",
    fee: 75000,
    deadline: "2026-11-25",
    eligibility: "Mahasiswa aktif",
    summary:
      "Kompetisi bidang sains dan penerapan teknologi bagi mahasiswa perguruan tinggi.",
    posterUrl: null,
    sourceUrl: null,
    isVerified: false,
    featured: false,
  },
  {
    id: 6,
    title: "Debat Bahasa Inggris Mahasiswa",
    organizer: "UGM English Club",
    category: "Bahasa",
    level: "Nasional",
    format: "Tim",
    fee: 100000,
    deadline: "2026-12-01",
    eligibility: "Mahasiswa aktif",
    summary:
      "Kompetisi debat bahasa Inggris untuk menguji kemampuan argumentasi dan komunikasi peserta.",
    posterUrl: null,
    sourceUrl: null,
    isVerified: false,
    featured: false,
  },
];

const categories = [
  "Semua",
  "Teknologi",
  "Bisnis",
  "Desain",
  "Karya Tulis",
  "Sains",
  "Bahasa",
];

// ============================================================
// 2. FUNGSI BANTU
// ============================================================

function formatCurrency(amount: number): string {
  if (amount === 0) return "Gratis";

  return `Rp${new Intl.NumberFormat("id-ID").format(amount)}`;
}

function formatDate(dateString: string): string {
  const [year, month, day] = dateString.split("-").map(Number);
  const monthNames = [
    "Januari",
    "Februari",
    "Maret",
    "April",
    "Mei",
    "Juni",
    "Juli",
    "Agustus",
    "September",
    "Oktober",
    "November",
    "Desember",
  ];

  return `${String(day).padStart(2, "0")} ${monthNames[month - 1]} ${year}`;
}

function getDaysLeft(dateString: string, todayString: string): number {
  const [year, month, day] = dateString.split("-").map(Number);
  const [todayYear, todayMonth, todayDay] = todayString
    .split("-")
    .map(Number);

  const deadline = Date.UTC(year, month - 1, day);
  const today = Date.UTC(todayYear, todayMonth - 1, todayDay);

  return Math.round((deadline - today) / 86400000);
}

function getDeadlineLabel(
  dateString: string,
  todayString: string | null
): string {
  if (!todayString) return formatDate(dateString);

  const days = getDaysLeft(dateString, todayString);

  if (days < 0) return "Pendaftaran ditutup";
  if (days === 0) return "Tutup hari ini";
  if (days === 1) return "1 hari lagi";

  return `${days} hari lagi`;
}

// ============================================================
// 3. IKON
// ============================================================

function SearchIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-4-4" />
    </svg>
  );
}

function SunIcon() {
  return (
    <svg
      className="h-[18px] w-[18px]"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      aria-hidden="true"
    >
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2v2M12 20v2M4.93 4.93l1.42 1.42M17.65 17.65l1.42 1.42M2 12h2M20 12h2M4.93 19.07l1.42-1.42M17.65 6.35l1.42-1.42" />
    </svg>
  );
}

function MoonIcon() {
  return (
    <svg
      className="h-[18px] w-[18px]"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M20.5 15.5A8.5 8.5 0 0 1 8.5 3.5 8.5 8.5 0 1 0 20.5 15.5Z" />
    </svg>
  );
}

function ArrowIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M7 17 17 7M7 7h10v10" />
    </svg>
  );
}

function ChevronIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="m6 9 6 6 6-6" />
    </svg>
  );
}

function CheckIcon() {
  return (
    <svg
      className="h-3 w-3 shrink-0"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="m5 12 4 4L19 6" />
    </svg>
  );
}

// ============================================================
// 4. POSTER LOMBA PILIHAN
// ============================================================

function CompetitionPoster({
  competition,
}: {
  competition: Competition;
}) {
  if (competition.posterUrl) {
    return (
      <img
        src={competition.posterUrl}
        alt={`Poster ${competition.title}`}
        className="h-full w-full object-cover"
      />
    );
  }

  return (
    <div className="relative flex h-full min-h-[132px] flex-col justify-between overflow-hidden bg-[#E7E3D7] p-4 text-[#2C2C2C] dark:bg-[#252822] dark:text-[#EBEAE4]">
      <div className="flex items-center justify-between">
        <span className="font-mono text-[9px] font-bold uppercase tracking-[0.16em] opacity-65">
          JEJAKARSA
        </span>
        <span className="font-mono text-[10px] font-bold tabular-nums opacity-65">
          {String(competition.id).padStart(2, "0")}
        </span>
      </div>

      <div className="relative z-10">
        <p className="font-mono text-[9px] font-bold uppercase tracking-widest opacity-65">
          {competition.category}
        </p>
        <p className="mt-2 max-w-[150px] font-sans text-lg font-bold leading-tight">
          {competition.title}
        </p>
        <p className="mt-2 font-mono text-[8px] uppercase tracking-wider opacity-60">
          Poster belum tersedia
        </p>
      </div>

      <div className="pointer-events-none absolute -bottom-10 -right-2 font-sans text-[130px] font-black leading-none opacity-[0.045]">
        {competition.category.charAt(0)}
      </div>
    </div>
  );
}

// ============================================================
// 5. BARIS KOMPETISI PADAT
// ============================================================

function OpportunityRow({
  competition,
  todayString,
  expanded,
  onToggle,
}: OpportunityRowProps) {
  const daysLeft = todayString
    ? getDaysLeft(competition.deadline, todayString)
    : null;
  const isUrgent = daysLeft !== null && daysLeft >= 0 && daysLeft <= 3;
  const isClosed = daysLeft !== null && daysLeft < 0;

  return (
    <article
      className={`overflow-hidden border-b border-[#D9D6CC] transition-colors dark:border-[#34342F] ${
        expanded
          ? "bg-white dark:bg-[#1D1D1A]"
          : "bg-transparent hover:bg-white dark:hover:bg-[#1D1D1A]"
      }`}
    >
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={expanded}
        className="group grid w-full grid-cols-1 gap-3 px-3 py-3 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#65745A] sm:px-4 lg:grid-cols-[minmax(190px,1.1fr)_minmax(220px,2fr)_142px_112px_20px] lg:items-center lg:gap-4 lg:py-3"
      >
        {/* KIRI: KATEGORI, PENYELENGGARA, VERIFIKASI */}
        <div className="flex min-w-0 flex-wrap items-center gap-x-2 gap-y-1.5 lg:block">
          <span className="inline-flex w-fit items-center border border-[#C9CFC1] bg-[#EDF0E9] px-2 py-1 font-mono text-[9px] font-bold uppercase tracking-wide text-[#526249] dark:border-[#495542] dark:bg-[#252C23] dark:text-[#B4C0A8]">
            {competition.category}
          </span>
          <span className="min-w-0 truncate text-[11px] text-[#77766D] dark:text-[#AAA99F] lg:mt-1.5 lg:block">
            {competition.organizer}
          </span>
          {competition.isVerified && (
            <span className="inline-flex items-center gap-1 text-[9px] font-semibold text-[#65745A] dark:text-[#A8B99A] lg:mt-1 lg:flex">
              <CheckIcon />
              Sumber diperiksa
            </span>
          )}
        </div>

        {/* TENGAH: JUDUL */}
        <div className="min-w-0 self-center">
          <h3 className="font-sans text-sm font-bold leading-snug text-[#2C2C2C] transition-colors group-hover:text-[#526249] dark:text-[#EBEAE4] dark:group-hover:text-[#B5C2A9] sm:text-[15px]">
            {competition.title}
          </h3>
          <p className="mt-1 truncate text-[10px] text-[#88867C] dark:text-[#99988E]">
            {competition.level} <span className="px-1">·</span> {competition.format}
            <span className="px-1">·</span> {competition.eligibility}
          </p>
        </div>

        {/* KANAN: TENGGAT */}
        <div className="flex items-center justify-between border-t border-[#E7E4DB] pt-2 dark:border-[#34342F] lg:block lg:border-t-0 lg:pt-0">
          <span className="font-sans text-[9px] font-semibold uppercase tracking-wider text-[#929087] dark:text-[#85857C] lg:hidden">
            Tenggat
          </span>
          <div className="text-right lg:text-left">
            <time
              dateTime={competition.deadline}
              className="block whitespace-nowrap font-mono text-[11px] font-bold tabular-nums text-[#383A34] dark:text-[#EBEAE4]"
            >
              {formatDate(competition.deadline)}
            </time>
            <span
              className={`mt-0.5 block whitespace-nowrap font-mono text-[9px] font-bold tabular-nums ${
                isUrgent
                  ? "text-[#E06B42]"
                  : isClosed
                    ? "text-[#929087] dark:text-[#85857C]"
                    : "text-[#65745A] dark:text-[#A8B99A]"
              }`}
            >
              {getDeadlineLabel(competition.deadline, todayString)}
            </span>
          </div>
        </div>

        {/* KANAN: BIAYA */}
        <div className="flex items-center justify-between lg:block lg:text-right">
          <span className="font-sans text-[9px] font-semibold uppercase tracking-wider text-[#929087] dark:text-[#85857C] lg:hidden">
            Biaya
          </span>
          <span className="whitespace-nowrap font-mono text-[11px] font-bold tabular-nums text-[#383A34] dark:text-[#EBEAE4]">
            {formatCurrency(competition.fee)}
          </span>
        </div>

        {/* PENANDA INTERAKSI */}
        <span className="hidden justify-self-end text-[#8B8A80] transition-transform group-hover:translate-x-0.5 group-hover:text-[#65745A] lg:inline-flex">
          {expanded ? (
            <ChevronIcon className="h-4 w-4 rotate-180" />
          ) : (
            <ArrowIcon className="h-4 w-4" />
          )}
        </span>
      </button>

      {/* DETAIL TAMBAHAN SAAT BARIS DIBUKA */}
      {expanded && (
        <div className="border-t border-[#E7E4DB] bg-[#F8F7F1] px-4 py-3 dark:border-[#34342F] dark:bg-[#191916] sm:px-5">
          <div className="grid gap-3 sm:grid-cols-[1fr_auto] sm:items-end">
            <div>
              <p className="max-w-3xl text-xs leading-5 text-[#66665D] dark:text-[#B6B5AA]">
                {competition.summary}
              </p>
              <p className="mt-2 text-[10px] text-[#89877D] dark:text-[#96958B]">
                Peserta: {competition.eligibility}
              </p>
            </div>
            {competition.sourceUrl ? (
              <a
                href={competition.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(event) => event.stopPropagation()}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#526249] hover:underline dark:text-[#B4C0A8]"
              >
                Buka sumber resmi <ArrowIcon className="h-3.5 w-3.5" />
              </a>
            ) : (
              <span className="text-[10px] text-[#929087] dark:text-[#85857C]">
                Tautan sumber belum ditambahkan
              </span>
            )}
          </div>
        </div>
      )}
    </article>
  );
}

// ============================================================
// 6. HALAMAN UTAMA
// ============================================================

export default function Home() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Semua");
  const [feeFilter, setFeeFilter] = useState("Semua");
  const [deadlineFilter, setDeadlineFilter] = useState(false);
  const [sortBy, setSortBy] = useState("deadline");
  const [visibleCount, setVisibleCount] = useState(6);
  const [todayString, setTodayString] = useState<string | null>(null);
  const [expandedCompetitionId, setExpandedCompetitionId] = useState<number | null>(null);

  // ----------------------------------------------------------
  // TANGGAL HARI INI
  // Dibaca setelah komponen dipasang di browser untuk menjaga
  // hasil prerender Next.js tetap stabil.
  // ----------------------------------------------------------

  useEffect(() => {
    const updateToday = () => {
      const now = new Date();
      const year = now.getFullYear();
      const month = String(now.getMonth() + 1).padStart(2, "0");
      const day = String(now.getDate()).padStart(2, "0");
      setTodayString(`${year}-${month}-${day}`);
    };

    updateToday();

    // Perbarui tanggal jika halaman tetap terbuka melewati tengah malam.
    const intervalId = window.setInterval(updateToday, 60_000);
    return () => window.clearInterval(intervalId);
  }, []);

  // ----------------------------------------------------------
  // TEMA
  // ----------------------------------------------------------

  useEffect(() => {
    try {
      const savedTheme = localStorage.getItem("jejakarsa-theme");
      const prefersDark = window.matchMedia(
        "(prefers-color-scheme: dark)"
      ).matches;

      const shouldUseDark =
        savedTheme === "dark" ||
        (savedTheme === null && prefersDark);

      setIsDarkMode(shouldUseDark);
      document.documentElement.classList.toggle("dark", shouldUseDark);
    } catch {
      // Gunakan tema terang jika penyimpanan tidak tersedia.
    }
  }, []);

  const toggleTheme = () => {
    const nextTheme = !isDarkMode;
    setIsDarkMode(nextTheme);
    document.documentElement.classList.toggle("dark", nextTheme);

    try {
      localStorage.setItem(
        "jejakarsa-theme",
        nextTheme ? "dark" : "light"
      );
    } catch {
      // Perubahan tema tetap berlaku selama halaman terbuka.
    }
  };

  // ----------------------------------------------------------
  // PENCARIAN, FILTER, DAN PENGURUTAN
  // Logika useMemo dari versi sebelumnya tetap dipertahankan.
  // ----------------------------------------------------------

  const filteredCompetitions = useMemo(() => {
    let result = [...competitions];
    const query = searchQuery.trim().toLowerCase();

    if (query) {
      result = result.filter((item) => {
        const searchableText = [
          item.title,
          item.organizer,
          item.category,
          item.level,
          item.format,
          item.eligibility,
          item.summary,
        ]
          .join(" ")
          .toLowerCase();

        return searchableText.includes(query);
      });
    }

    if (selectedCategory !== "Semua") {
      result = result.filter(
        (item) => item.category === selectedCategory
      );
    }

    if (feeFilter === "Gratis") {
      result = result.filter((item) => item.fee === 0);
    }

    if (feeFilter === "Berbayar") {
      result = result.filter((item) => item.fee > 0);
    }

    if (deadlineFilter && todayString) {
      result = result.filter((item) => {
        const daysLeft = getDaysLeft(item.deadline, todayString);
        return daysLeft >= 0 && daysLeft <= 7;
      });
    }

    result.sort((a, b) => {
      if (sortBy === "deadline") {
        return a.deadline.localeCompare(b.deadline);
      }

      if (sortBy === "deadline-desc") {
        return b.deadline.localeCompare(a.deadline);
      }

      if (sortBy === "name") {
        return a.title.localeCompare(b.title);
      }

      return 0;
    });

    return result;
  }, [
    searchQuery,
    selectedCategory,
    feeFilter,
    deadlineFilter,
    sortBy,
    todayString,
  ]);

  useEffect(() => {
    setVisibleCount(6);
    setExpandedCompetitionId(null);
  }, [searchQuery, selectedCategory, feeFilter, deadlineFilter, sortBy]);

  const featuredCompetition = competitions.find((item) => item.featured);
  const displayedCompetitions = filteredCompetitions.slice(0, visibleCount);

  const clearFilters = () => {
    setSearchQuery("");
    setSelectedCategory("Semua");
    setFeeFilter("Semua");
    setDeadlineFilter(false);
    setSortBy("deadline");
  };

  const toggleExpandedCompetition = (id: number) => {
    setExpandedCompetitionId((currentId) =>
      currentId === id ? null : id
    );
  };

  // ----------------------------------------------------------
  // TAMPILAN
  // ----------------------------------------------------------

  return (
    <div className="min-h-screen bg-[#F2EFE6] font-sans text-[#2C2C2C] transition-colors duration-300 dark:bg-[#121211] dark:text-[#EBEAE4]">
      {/* NAVBAR */}
      <nav className="sticky top-0 z-50 border-b border-[#D8D5CA] bg-[#F2EFE6]/95 backdrop-blur-sm dark:border-[#34342F] dark:bg-[#121211]/95">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-3 sm:px-8">
          <Link href="/" className="flex shrink-0 flex-col">
            <span className="font-serif text-2xl font-bold tracking-tight text-[#2C2C2C] dark:text-[#EBEAE4]">
              jejakarsa<span className="text-[#65745A]">.</span>
            </span>
            <span className="font-mono text-[8px] font-bold uppercase tracking-[0.18em] text-[#89877D] dark:text-[#8F8E84]">
              Direktori lomba mahasiswa
            </span>
          </Link>

          <div className="hidden items-center gap-7 md:flex">
            <Link
              href="#katalog"
              className="text-xs font-semibold text-[#66665D] transition-colors hover:text-[#526249] dark:text-[#B5B4AA] dark:hover:text-[#EBEAE4]"
            >
              Daftar Lomba
            </Link>
            <Link
              href="#arsip"
              className="text-xs font-semibold text-[#66665D] transition-colors hover:text-[#526249] dark:text-[#B5B4AA] dark:hover:text-[#EBEAE4]"
            >
              Kisah Juara
            </Link>
            <Link
              href="#tentang"
              className="text-xs font-semibold text-[#66665D] transition-colors hover:text-[#526249] dark:text-[#B5B4AA] dark:hover:text-[#EBEAE4]"
            >
              Tentang
            </Link>
          </div>

          <div className="flex shrink-0 items-center gap-2 sm:gap-3">
            <button
              onClick={toggleTheme}
              type="button"
              aria-label={
                isDarkMode
                  ? "Mode gelap aktif, ganti ke mode terang"
                  : "Mode terang aktif, ganti ke mode gelap"
              }
              title={isDarkMode ? "Ganti ke mode terang" : "Ganti ke mode gelap"}
              className="flex h-9 w-9 items-center justify-center border border-[#D8D5CA] text-[#65745A] transition-colors hover:bg-[#E7E3D7] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#65745A] dark:border-[#41413A] dark:text-[#EBEAE4] dark:hover:bg-[#252520]"
            >
              {isDarkMode ? <MoonIcon /> : <SunIcon />}
            </button>

            <Link
              href="#bagikan-peluang"
              className="inline-flex items-center justify-center border border-[#2C2C2C] bg-[#2C2C2C] px-3 py-2.5 text-[10px] font-bold uppercase tracking-wider text-[#F5F5F0] transition-colors hover:border-[#65745A] hover:bg-[#65745A] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#65745A] dark:border-[#EBEAE4] dark:bg-[#EBEAE4] dark:text-[#121211] dark:hover:border-[#65745A] dark:hover:bg-[#65745A] dark:hover:text-white sm:px-4"
            >
              Bagikan Peluang
            </Link>
          </div>
        </div>
      </nav>

      <main className="mx-auto max-w-7xl px-5 pb-16 sm:px-8">
        {/* HERO */}
        <section className="grid grid-cols-1 gap-7 border-b border-[#D8D5CA] py-10 dark:border-[#34342F] md:grid-cols-[minmax(0,1.5fr)_minmax(230px,0.65fr)] md:items-end md:py-14">
          <div>
            <div className="mb-4 flex items-center gap-3">
              <span className="h-px w-8 bg-[#65745A]" />
              <span className="font-mono text-[9px] font-bold uppercase tracking-[0.18em] text-[#65745A] dark:text-[#A8B99A]">
                Referensi kompetisi mahasiswa
              </span>
            </div>

            <h1 className="max-w-3xl font-serif text-4xl font-medium leading-[1.02] tracking-tight text-[#2C2C2C] dark:text-[#EBEAE4] sm:text-5xl md:text-6xl">
              Temukan kompetisi.
              <br />
              <span className="italic text-[#65745A] dark:text-[#A8B99A]">
                Siapkan langkahmu.
              </span>
            </h1>

            <p className="mt-4 max-w-2xl text-sm leading-6 text-[#6F6D63] dark:text-[#B5B4AA]">
              Cari lomba berdasarkan bidang, biaya pendaftaran, persyaratan,
              dan tenggat waktu. Bandingkan informasinya sebelum mendaftar.
            </p>

            <form
              onSubmit={(event) => event.preventDefault()}
              className="mt-6 flex max-w-2xl items-center border border-[#CFCBBC] bg-[#FAF9F5] p-1 transition-colors focus-within:border-[#65745A] focus-within:ring-1 focus-within:ring-[#65745A] dark:border-[#41413A] dark:bg-[#1B1B18]"
            >
              <div className="flex min-w-0 flex-1 items-center gap-3 px-3">
                <SearchIcon className="h-4 w-4 shrink-0 text-[#858276]" />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(event) => setSearchQuery(event.target.value)}
                  placeholder="Cari nama lomba, bidang, atau penyelenggara..."
                  className="w-full min-w-0 border-none bg-transparent py-2.5 font-sans text-sm text-[#2C2C2C] outline-none placeholder:text-[#9A978C] focus:ring-0 dark:text-[#EBEAE4] dark:placeholder:text-[#77766D]"
                  aria-label="Cari lomba"
                />
              </div>
              <button
                type="submit"
                className="flex h-10 w-10 shrink-0 items-center justify-center bg-[#65745A] text-white transition-colors hover:bg-[#526249]"
                aria-label="Cari lomba"
              >
                <SearchIcon className="h-4 w-4" />
              </button>
            </form>

            {/* FILTER CEPAT */}
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <span className="mr-1 font-mono text-[9px] font-bold uppercase tracking-wider text-[#8C897F] dark:text-[#8F8E84]">
                Filter cepat
              </span>
              <button
                type="button"
                onClick={() => {
                  setFeeFilter("Semua");
                  setDeadlineFilter(false);
                }}
                className={`rounded-full border px-3 py-1.5 font-sans text-[10px] font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#65745A] ${
                  feeFilter === "Semua" && !deadlineFilter
                    ? "border-[#65745A] bg-[#65745A] text-white"
                    : "border-[#C9C6BB] bg-transparent text-[#5F5E55] hover:border-[#65745A] hover:bg-white dark:border-[#47473F] dark:text-[#C3C2B8] dark:hover:bg-[#20201C]"
                }`}
              >
                Semua lomba
              </button>
              <button
                type="button"
                onClick={() => {
                  setFeeFilter("Gratis");
                  setDeadlineFilter(false);
                }}
                className={`rounded-full border px-3 py-1.5 font-sans text-[10px] font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#65745A] ${
                  feeFilter === "Gratis"
                    ? "border-[#65745A] bg-[#65745A] text-white"
                    : "border-[#C9C6BB] bg-transparent text-[#5F5E55] hover:border-[#65745A] hover:bg-white dark:border-[#47473F] dark:text-[#C3C2B8] dark:hover:bg-[#20201C]"
                }`}
              >
                Gratis
              </button>
              <button
                type="button"
                onClick={() => {
                  setFeeFilter("Semua");
                  setDeadlineFilter((current) => !current);
                }}
                className={`rounded-full border px-3 py-1.5 font-sans text-[10px] font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#65745A] ${
                  deadlineFilter
                    ? "border-[#65745A] bg-[#65745A] text-white"
                    : "border-[#C9C6BB] bg-transparent text-[#5F5E55] hover:border-[#65745A] hover:bg-white dark:border-[#47473F] dark:text-[#C3C2B8] dark:hover:bg-[#20201C]"
                }`}
              >
                Segera ditutup
              </button>
            </div>
          </div>

          <aside className="grid grid-cols-2 gap-3 border-t border-[#D8D5CA] pt-4 dark:border-[#34342F] md:block md:border-l md:border-t-0 md:pb-1 md:pl-5 md:pt-0">
            <div>
              <span className="font-mono text-[9px] font-bold uppercase tracking-wider text-[#8C897F] dark:text-[#8F8E84]">
                Isi katalog
              </span>
              <p className="mt-1 font-sans text-xs leading-5 text-[#66655C] dark:text-[#B5B4AA]">
                Kompetisi dari berbagai bidang dan penyelenggara.
              </p>
            </div>
            <div className="border-l border-[#D8D5CA] pl-3 dark:border-[#34342F] md:mt-4 md:border-l-0 md:border-t md:pl-0 md:pt-4">
              <span className="font-mono text-[9px] font-bold uppercase tracking-wider text-[#8C897F] dark:text-[#8F8E84]">
                Sebelum mendaftar
              </span>
              <p className="mt-1 font-sans text-xs leading-5 text-[#66655C] dark:text-[#B5B4AA]">
                Periksa biaya, persyaratan, dan tenggat dari sumbernya.
              </p>
            </div>
          </aside>
        </section>

        {/* LOMBA PILIHAN */}
        {featuredCompetition && (
          <section className="pt-9">
            <div className="mb-3 flex items-end justify-between border-b-2 border-[#2C2C2C] pb-2 dark:border-[#EBEAE4]">
              <div>
                <span className="font-mono text-[9px] font-bold uppercase tracking-wider text-[#65745A] dark:text-[#A8B99A]">
                  01 / PILIHAN
                </span>
                <h2 className="mt-1 font-serif text-2xl font-medium text-[#2C2C2C] dark:text-[#EBEAE4] sm:text-3xl">
                  Lomba pilihan
                </h2>
              </div>
              <span className="hidden font-mono text-[9px] font-bold uppercase tracking-wider text-[#8C897F] dark:text-[#8F8E84] sm:block">
                Pilihan redaksi
              </span>
            </div>

            <article className="grid grid-cols-1 overflow-hidden border border-[#D8D5CA] bg-[#FAF9F5] dark:border-[#34342F] dark:bg-[#1A1A18] sm:grid-cols-[132px_minmax(0,1fr)]">
              <div className="h-[132px] overflow-hidden sm:h-full">
                <CompetitionPoster competition={featuredCompetition} />
              </div>
              <div className="flex min-w-0 flex-col justify-between gap-3 p-4 sm:flex-row sm:items-center sm:gap-5 sm:px-5">
                <div className="min-w-0">
                  <div className="mb-1.5 flex flex-wrap items-center gap-2">
                    <span className="border border-[#C9CFC1] bg-[#EDF0E9] px-2 py-0.5 font-mono text-[9px] font-bold uppercase text-[#526249] dark:border-[#495542] dark:bg-[#252C23] dark:text-[#B4C0A8]">
                      {featuredCompetition.category}
                    </span>
                    <span className="font-sans text-[10px] text-[#77766D] dark:text-[#AAA99F]">
                      {featuredCompetition.organizer}
                    </span>
                    {!featuredCompetition.isVerified && (
                      <span className="font-sans text-[9px] text-[#8C897F] dark:text-[#8F8E84]">
                        Belum diperiksa
                      </span>
                    )}
                  </div>
                  <h3 className="font-sans text-base font-bold leading-snug text-[#2C2C2C] dark:text-[#EBEAE4]">
                    {featuredCompetition.title}
                  </h3>
                  <p className="mt-1 line-clamp-2 max-w-3xl font-sans text-xs leading-5 text-[#6F6D63] dark:text-[#B5B4AA]">
                    {featuredCompetition.summary}
                  </p>
                </div>
                <div className="grid shrink-0 grid-cols-2 gap-4 border-t border-[#E5E2D8] pt-3 sm:w-[220px] sm:border-l sm:border-t-0 sm:pl-5 sm:pt-0 dark:border-[#34342F]">
                  <div>
                    <span className="block font-sans text-[9px] font-semibold uppercase tracking-wider text-[#8C897F] dark:text-[#8F8E84]">
                      Tenggat
                    </span>
                    <time
                      dateTime={featuredCompetition.deadline}
                      className="mt-1 block whitespace-nowrap font-mono text-[11px] font-bold tabular-nums text-[#2C2C2C] dark:text-[#EBEAE4]"
                    >
                      {formatDate(featuredCompetition.deadline)}
                    </time>
                    <span
                      className={`mt-0.5 block font-mono text-[9px] font-bold tabular-nums ${
                        todayString &&
                        getDaysLeft(featuredCompetition.deadline, todayString) >= 0 &&
                        getDaysLeft(featuredCompetition.deadline, todayString) <= 3
                          ? "text-[#E06B42]"
                          : "text-[#65745A] dark:text-[#A8B99A]"
                      }`}
                    >
                      {getDeadlineLabel(featuredCompetition.deadline, todayString)}
                    </span>
                  </div>
                  <div>
                    <span className="block font-sans text-[9px] font-semibold uppercase tracking-wider text-[#8C897F] dark:text-[#8F8E84]">
                      Biaya
                    </span>
                    <span className="mt-1 block whitespace-nowrap font-mono text-[11px] font-bold tabular-nums text-[#2C2C2C] dark:text-[#EBEAE4]">
                      {formatCurrency(featuredCompetition.fee)}
                    </span>
                    <span className="mt-0.5 block font-sans text-[9px] text-[#8C897F] dark:text-[#8F8E84]">
                      {featuredCompetition.level} · {featuredCompetition.format}
                    </span>
                  </div>
                </div>
              </div>
            </article>
          </section>
        )}

        {/* DAFTAR LOMBA */}
        <section id="katalog" className="scroll-mt-24 pt-10">
          <div className="flex flex-col justify-between gap-3 border-b-2 border-[#2C2C2C] pb-3 dark:border-[#EBEAE4] sm:flex-row sm:items-end">
            <div>
              <span className="font-mono text-[9px] font-bold uppercase tracking-wider text-[#65745A] dark:text-[#A8B99A]">
                02 / KATALOG
              </span>
              <h2 className="mt-1 font-serif text-2xl font-medium text-[#2C2C2C] dark:text-[#EBEAE4] sm:text-3xl">
                Semua lomba
              </h2>
              <p className="mt-1 font-sans text-xs text-[#77766D] dark:text-[#AAA99F]">
                Gunakan filter untuk mempersempit pilihan.
              </p>
            </div>
            <span className="font-mono text-[10px] font-bold tabular-nums text-[#77766D] dark:text-[#AAA99F]">
              {String(filteredCompetitions.length).padStart(2, "0")} HASIL
            </span>
          </div>

          {/* FILTER BIDANG: HORIZONTAL SCROLL DI MOBILE */}
          <div className="-mx-5 overflow-x-auto px-5 pb-2 pt-4 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden sm:mx-0 sm:overflow-visible sm:px-0">
            <div className="flex w-max min-w-full items-center gap-2 pr-5 sm:w-auto sm:min-w-0 sm:flex-wrap sm:pr-0">
              <span className="mr-1 shrink-0 font-mono text-[9px] font-bold uppercase tracking-wider text-[#8C897F] dark:text-[#8F8E84]">
                Bidang
              </span>
              {categories.map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => setSelectedCategory(category)}
                  aria-pressed={selectedCategory === category}
                  className={`shrink-0 rounded-full border px-3.5 py-1.5 font-sans text-[10px] font-semibold transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#65745A] ${
                    selectedCategory === category
                      ? "border-[#65745A] bg-[#65745A] text-white shadow-sm"
                      : "border-[#C9C6BB] bg-[#F8F7F1] text-[#5F5E55] hover:border-[#65745A] hover:bg-white dark:border-[#47473F] dark:bg-[#191916] dark:text-[#C3C2B8] dark:hover:bg-[#20201C]"
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          {/* FILTER BIAYA, TENGGAT, DAN PENGURUTAN */}
          <div className="flex flex-col justify-between gap-3 border-b border-[#D8D5CA] py-3 dark:border-[#34342F] sm:flex-row sm:items-center">
            <div className="flex flex-wrap items-center gap-2">
              <span className="mr-1 font-mono text-[9px] font-bold uppercase tracking-wider text-[#8C897F] dark:text-[#8F8E84]">
                Biaya
              </span>
              {(["Semua", "Gratis", "Berbayar"] as const).map((filter) => (
                <button
                  key={filter}
                  type="button"
                  onClick={() => setFeeFilter(filter)}
                  aria-pressed={feeFilter === filter}
                  className={`rounded-full border px-3 py-1.5 font-sans text-[10px] font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#65745A] ${
                    feeFilter === filter
                      ? "border-[#65745A] bg-[#65745A] text-white"
                      : "border-[#C9C6BB] text-[#5F5E55] hover:border-[#65745A] hover:bg-white dark:border-[#47473F] dark:text-[#C3C2B8] dark:hover:bg-[#20201C]"
                  }`}
                >
                  {filter}
                </button>
              ))}

              <span className="mx-1 hidden h-4 w-px bg-[#D8D5CA] dark:bg-[#34342F] sm:block" />

              <button
                type="button"
                onClick={() => setDeadlineFilter((current) => !current)}
                aria-pressed={deadlineFilter}
                className={`rounded-full border px-3 py-1.5 font-sans text-[10px] font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#65745A] ${
                  deadlineFilter
                    ? "border-[#65745A] bg-[#65745A] text-white"
                    : "border-[#C9C6BB] text-[#5F5E55] hover:border-[#65745A] hover:bg-white dark:border-[#47473F] dark:text-[#C3C2B8] dark:hover:bg-[#20201C]"
                }`}
              >
                Segera ditutup
              </button>

              {(searchQuery ||
                selectedCategory !== "Semua" ||
                feeFilter !== "Semua" ||
                deadlineFilter) && (
                <button
                  type="button"
                  onClick={clearFilters}
                  className="ml-1 font-sans text-[10px] font-semibold text-[#65745A] underline underline-offset-2 hover:text-[#43513B] dark:text-[#A8B99A]"
                >
                  Reset
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 self-start sm:self-auto">
              <label
                htmlFor="sort-competitions"
                className="font-mono text-[9px] font-bold uppercase tracking-wider text-[#8C897F] dark:text-[#8F8E84]"
              >
                Urutkan
              </label>
              <select
                id="sort-competitions"
                value={sortBy}
                onChange={(event) => setSortBy(event.target.value)}
                className="border border-[#C9C6BB] bg-[#F8F7F1] px-2.5 py-1.5 font-sans text-[10px] font-semibold text-[#5F5E55] outline-none transition-colors focus:border-[#65745A] dark:border-[#47473F] dark:bg-[#191916] dark:text-[#C3C2B8]"
              >
                <option value="deadline">Tenggat terdekat</option>
                <option value="deadline-desc">Tenggat terjauh</option>
                <option value="name">Nama lomba</option>
              </select>
            </div>
          </div>

          {/* HEADER KOLOM DESKTOP */}
          <div className="hidden grid-cols-[minmax(190px,1.1fr)_minmax(220px,2fr)_142px_112px_20px] gap-4 border-b border-[#BEBBAF] px-4 py-2 lg:grid dark:border-[#4A4A42]">
            <span className="font-mono text-[9px] font-bold uppercase tracking-wider text-[#89877D] dark:text-[#929188]">
              Kategori / Penyelenggara
            </span>
            <span className="font-mono text-[9px] font-bold uppercase tracking-wider text-[#89877D] dark:text-[#929188]">
              Nama kompetisi
            </span>
            <span className="font-mono text-[9px] font-bold uppercase tracking-wider text-[#89877D] dark:text-[#929188]">
              Tenggat
            </span>
            <span className="text-right font-mono text-[9px] font-bold uppercase tracking-wider text-[#89877D] dark:text-[#929188]">
              Biaya
            </span>
            <span />
          </div>

          {/* BARIS KOMPETISI */}
          <div className="mt-1 border-t border-[#D9D6CC] dark:border-[#34342F]">
            {displayedCompetitions.length > 0 ? (
              displayedCompetitions.map((competition) => (
                <OpportunityRow
                  key={competition.id}
                  competition={competition}
                  todayString={todayString}
                  expanded={expandedCompetitionId === competition.id}
                  onToggle={() => toggleExpandedCompetition(competition.id)}
                />
              ))
            ) : (
              <div className="border-b border-dashed border-[#C9C6BB] px-5 py-12 text-center dark:border-[#41413A]">
                <span className="font-mono text-[9px] font-bold uppercase tracking-widest text-[#89877D] dark:text-[#929188]">
                  HASIL PENCARIAN
                </span>
                <h3 className="mt-3 font-serif text-2xl text-[#2C2C2C] dark:text-[#EBEAE4]">
                  Lomba belum ditemukan.
                </h3>
                <p className="mt-1 font-sans text-xs text-[#77766D] dark:text-[#AAA99F]">
                  Coba kata kunci atau filter yang berbeda.
                </p>
                <button
                  type="button"
                  onClick={clearFilters}
                  className="mt-4 border border-[#65745A] px-4 py-2 font-sans text-[10px] font-bold text-[#526249] transition-colors hover:bg-[#65745A] hover:text-white dark:text-[#B4C0A8]"
                >
                  Hapus filter
                </button>
              </div>
            )}
          </div>

          {filteredCompetitions.length > visibleCount && (
            <div className="flex justify-center border-b border-[#D8D5CA] py-4 dark:border-[#34342F]">
              <button
                type="button"
                onClick={() => setVisibleCount((count) => count + 6)}
                className="border border-[#C9C6BB] px-5 py-2 font-mono text-[9px] font-bold uppercase tracking-wider text-[#5F5E55] transition-colors hover:border-[#65745A] hover:bg-[#65745A] hover:text-white dark:border-[#47473F] dark:text-[#C3C2B8]"
              >
                Tampilkan lebih banyak
              </button>
            </div>
          )}
        </section>

        {/* KISAH JUARA / MARGINALIA */}
        <section id="arsip" className="scroll-mt-24 pt-12">
          <div className="mb-4 flex items-end justify-between border-b-2 border-[#2C2C2C] pb-2 dark:border-[#EBEAE4]">
            <div>
              <span className="font-mono text-[9px] font-bold uppercase tracking-wider text-[#65745A] dark:text-[#A8B99A]">
                03 / ARSIP PENGALAMAN
              </span>
              <h2 className="mt-1 font-serif text-2xl font-medium text-[#2C2C2C] dark:text-[#EBEAE4] sm:text-3xl">
                Kisah peserta
              </h2>
            </div>
            <span className="hidden font-mono text-[9px] font-bold uppercase tracking-wider text-[#89877D] dark:text-[#929188] sm:block">
              Kliping pengalaman
            </span>
          </div>

          <div className="grid gap-4 lg:grid-cols-[minmax(0,1.1fr)_minmax(280px,0.9fr)]">
            <div className="border border-[#D8D5CA] bg-[#FAF9F5] p-5 dark:border-[#34342F] dark:bg-[#1A1A18] sm:p-6">
              <div className="flex items-center justify-between border-b border-[#E5E2D8] pb-3 dark:border-[#34342F]">
                <span className="font-mono text-[9px] font-bold uppercase tracking-wider text-[#65745A] dark:text-[#A8B99A]">
                  CATATAN PESERTA
                </span>
                <span className="font-mono text-[9px] font-bold text-[#89877D] dark:text-[#929188]">
                  001 / ARSIP
                </span>
              </div>
              <blockquote className="mt-5 max-w-2xl font-serif text-xl italic leading-relaxed text-[#3D4038] dark:text-[#D8D7CF] sm:text-2xl">
                “Persiapan, strategi tim, dan pengalaman mengikuti lomba
                bisa menjadi pelajaran bagi peserta berikutnya.”
              </blockquote>
              <div className="mt-5 flex flex-wrap items-center justify-between gap-2 border-t border-[#E5E2D8] pt-3 dark:border-[#34342F]">
                <span className="font-sans text-[10px] text-[#89877D] dark:text-[#929188]">
                  Pratinjau isi arsip, bukan kutipan peserta.
                </span>
                <span className="font-mono text-[9px] font-bold uppercase tracking-wider text-[#65745A] dark:text-[#A8B99A]">
                  Menunggu dokumentasi
                </span>
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
              <div className="border-l-2 border-[#65745A] bg-[#EAE8DE] p-4 dark:bg-[#1B1D19]">
                <span className="font-mono text-[9px] font-bold uppercase tracking-wider text-[#65745A] dark:text-[#A8B99A]">
                  YANG AKAN DIMUAT
                </span>
                <h3 className="mt-2 font-sans text-sm font-bold text-[#2C2C2C] dark:text-[#EBEAE4]">
                  Proses persiapan
                </h3>
                <p className="mt-1 font-sans text-xs leading-5 text-[#6F6D63] dark:text-[#B5B4AA]">
                  Cara peserta membagi tugas, menyusun ide, dan menyiapkan karya.
                </p>
              </div>
              <div className="border-l-2 border-[#65745A] bg-[#EAE8DE] p-4 dark:bg-[#1B1D19]">
                <span className="font-mono text-[9px] font-bold uppercase tracking-wider text-[#65745A] dark:text-[#A8B99A]">
                  YANG AKAN DIMUAT
                </span>
                <h3 className="mt-2 font-sans text-sm font-bold text-[#2C2C2C] dark:text-[#EBEAE4]">
                  Catatan setelah lomba
                </h3>
                <p className="mt-1 font-sans text-xs leading-5 text-[#6F6D63] dark:text-[#B5B4AA]">
                  Hal yang berhasil, kendala yang ditemui, dan saran untuk peserta lain.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* BAGIKAN PELUANG */}
        <section id="bagikan-peluang" className="scroll-mt-24 pt-12">
          <div className="flex flex-col gap-4 border border-[#D8D5CA] bg-[#EAE8DE] p-5 dark:border-[#34342F] dark:bg-[#1A1A18] sm:flex-row sm:items-center sm:justify-between sm:px-6">
            <div>
              <span className="font-mono text-[9px] font-bold uppercase tracking-wider text-[#65745A] dark:text-[#A8B99A]">
                KONTRIBUSI / 04
              </span>
              <h2 className="mt-1 font-sans text-base font-bold text-[#2C2C2C] dark:text-[#EBEAE4]">
                Menemukan informasi lomba yang belum tercantum?
              </h2>
              <p className="mt-1 font-sans text-xs leading-5 text-[#6F6D63] dark:text-[#B5B4AA]">
                Fitur pengiriman informasi lomba sedang disiapkan.
              </p>
            </div>
            <span className="shrink-0 border border-[#C9C6BB] px-3 py-2 font-mono text-[9px] font-bold uppercase tracking-wider text-[#77766D] dark:border-[#47473F] dark:text-[#AAA99F]">
              Segera tersedia
            </span>
          </div>
        </section>

        {/* TENTANG JEJAKARSA */}
        <section id="tentang" className="scroll-mt-24 pt-12">
          <div className="border-t-2 border-[#2C2C2C] pt-5 dark:border-[#EBEAE4]">
            <span className="font-mono text-[9px] font-bold uppercase tracking-wider text-[#65745A] dark:text-[#A8B99A]">
              05 / TENTANG JEJAKARSA
            </span>
            <h2 className="mt-2 max-w-2xl font-serif text-2xl font-medium text-[#2C2C2C] dark:text-[#EBEAE4] sm:text-3xl">
              Direktori lomba untuk mahasiswa Indonesia.
            </h2>
            <p className="mt-3 max-w-3xl font-sans text-xs leading-6 text-[#6F6D63] dark:text-[#B5B4AA] sm:text-sm">
              Jejakarsa mengumpulkan informasi kompetisi dari berbagai penyelenggara.
              Informasi disusun agar mahasiswa lebih mudah mencari lomba, memeriksa
              persyaratan, dan membandingkan biaya serta jadwal pendaftaran.
            </p>

            <div className="mt-6 grid grid-cols-1 gap-4 border-t border-[#D8D5CA] pt-5 dark:border-[#34342F] sm:grid-cols-2 lg:grid-cols-4">
              <div>
                <span className="font-mono text-[9px] font-bold text-[#65745A] dark:text-[#A8B99A]">01 / SUMBER</span>
                <h3 className="mt-2 font-sans text-xs font-bold text-[#2C2C2C] dark:text-[#EBEAE4]">Informasi penyelenggara</h3>
                <p className="mt-1 font-sans text-[11px] leading-5 text-[#77766D] dark:text-[#AAA99F]">Tautan penyelenggara atau dokumen resmi dicantumkan bila tersedia.</p>
              </div>
              <div>
                <span className="font-mono text-[9px] font-bold text-[#65745A] dark:text-[#A8B99A]">02 / PESERTA</span>
                <h3 className="mt-2 font-sans text-xs font-bold text-[#2C2C2C] dark:text-[#EBEAE4]">Ketentuan peserta</h3>
                <p className="mt-1 font-sans text-[11px] leading-5 text-[#77766D] dark:text-[#AAA99F]">Periksa jenjang pendidikan, bidang, dan kriteria peserta.</p>
              </div>
              <div>
                <span className="font-mono text-[9px] font-bold text-[#65745A] dark:text-[#A8B99A]">03 / BIAYA</span>
                <h3 className="mt-2 font-sans text-xs font-bold text-[#2C2C2C] dark:text-[#EBEAE4]">Biaya pendaftaran</h3>
                <p className="mt-1 font-sans text-[11px] leading-5 text-[#77766D] dark:text-[#AAA99F]">Bedakan kompetisi gratis dan berbayar berdasarkan ketentuan.</p>
              </div>
              <div>
                <span className="font-mono text-[9px] font-bold text-[#65745A] dark:text-[#A8B99A]">04 / TENGGAT</span>
                <h3 className="mt-2 font-sans text-xs font-bold text-[#2C2C2C] dark:text-[#EBEAE4]">Jadwal pendaftaran</h3>
                <p className="mt-1 font-sans text-[11px] leading-5 text-[#77766D] dark:text-[#AAA99F]">Tanggal pendaftaran perlu diperiksa dan diperbarui sesuai sumber.</p>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="mt-12 border-t border-[#D8D5CA] bg-[#EAE8DE] dark:border-[#34342F] dark:bg-[#171715]">
        <div className="mx-auto flex max-w-7xl flex-col justify-between gap-4 px-5 py-6 sm:px-8 md:flex-row md:items-end">
          <div>
            <Link
              href="/"
              className="font-serif text-xl font-bold tracking-tight text-[#2C2C2C] dark:text-[#EBEAE4]"
            >
              jejakarsa<span className="text-[#65745A]">.</span>
            </Link>
            <p className="mt-1 max-w-sm font-sans text-[10px] leading-5 text-[#77766D] dark:text-[#AAA99F]">
              Direktori lomba dan kompetisi untuk mahasiswa Indonesia.
            </p>
          </div>
          <div className="font-mono text-[9px] font-bold uppercase tracking-wider text-[#89877D] dark:text-[#929188] md:text-right">
            © {todayString ? todayString.slice(0, 4) : "2026"} JEJAKARSA
          </div>
        </div>
      </footer>

      {/* PEMBERITAHUAN DATA DEMO */}
      <div className="border-t border-[#D8D5CA] bg-[#F2EFE6] px-5 py-2.5 text-center dark:border-[#34342F] dark:bg-[#121211]">
        <p className="font-mono text-[8px] font-bold uppercase tracking-wider text-[#77766D] dark:text-[#8F8E84]">
          Versi demonstrasi — data lomba belum diverifikasi.
        </p>
      </div>
    </div>
  );
}
