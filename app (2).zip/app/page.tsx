"use client";

import Link from "next/link";
import { useMemo } from "react";
import { competitions, playbooks } from "@/lib/demo-data";
import { useApp } from "@/components/app-provider";
import { OpportunityCard } from "@/components/opportunity-card";
import { LinkButton, SectionTitle } from "@/components/ui";
import { Icon } from "@/components/icons";
import { rankByFit } from "@/lib/recommendations";
import { StoryHome } from "@/components/stories/story-home";

export default function HomePage() {
  const { profile } = useApp();
  const profileReady = Boolean(profile.educationLevel && profile.studyProgram);
  const hasPreferences = Boolean(profile.educationLevel || profile.preferredCategories.length || profile.preferredMode);
  const featured = useMemo(() => (hasPreferences ? rankByFit(competitions, profile) : [...competitions].sort((a, b) => a.deadline.localeCompare(b.deadline))).slice(0, 3), [hasPreferences, profile]);
  const nearest = competitions.slice().sort((a, b) => a.deadline.localeCompare(b.deadline))[0];

  return (
    <div className="dashboard-page">
      <StoryHome/>

      <section className="hero-panel home-hero">
        <div className="hero-copy">
          <div className="hero-eyebrow"><span className="eyebrow-line"/> INFORMASI LOMBA MAHASISWA</div>
          <h1>Temukan Lomba.<br/><em>Raih Prestasi.</em></h1>
          <div className="hero-actions"><LinkButton href="/explore" size="lg">Cari Lomba <Icon name="arrow" size={16}/></LinkButton><Link href="/playbook" className="hero-text-link">Baca Panduan <Icon name="arrowUpRight" size={14}/></Link></div>
        </div>
        <span className="hero-watermark" aria-hidden="true">j.</span>
      </section>

      {!profileReady && (
        <section className="profile-nudge home-profile-nudge panel" aria-label="Lengkapi profil peserta">
          <div className="profile-nudge-symbol"><Icon name="target" size={19}/></div>
          <div className="profile-nudge-copy">
            <h2>Lengkapi profil untuk cek kelayakan lomba.</h2>
          </div>
          <LinkButton href="/profile" variant="secondary" size="sm" className="home-profile-link">Lengkapi <Icon name="arrowUpRight" size={13}/></LinkButton>
        </section>
      )}

      <section className="content-section">
        <SectionTitle title={hasPreferences ? "Lomba untukmu" : "Lomba dengan tenggat terdekat"} subtitle={hasPreferences ? "Urutan lomba disesuaikan dengan bidang pilihan dan hasil pemeriksaan profil." : "Lomba dengan batas pendaftaran paling dekat."} action={<Link href="/explore" className="section-link">Lihat semua lomba <Icon name="arrow" size={14}/></Link>}/>
        <div className="opportunity-grid">{featured.map((competition) => <OpportunityCard key={competition.id} competition={competition}/>)}</div>
      </section>

      <section className="split-feature-grid home-support-grid" aria-label="Pantau tenggat dan panduan">
        <div className="deadline-feature panel-dark home-deadline-compact">
          <div className="feature-overline"><span className="live-dot"/> PANTAU TENGGAT</div>
          <div className="home-deadline-date">
            <strong>{new Date(nearest.deadline + "T12:00:00").getDate().toString().padStart(2, "0")}</strong>
            <span>{new Intl.DateTimeFormat("id-ID", { month: "long", year: "numeric" }).format(new Date(nearest.deadline + "T12:00:00"))}</span>
          </div>
          <h3>{nearest.title}</h3>
          <Link href={`/opportunities/${nearest.slug}`} className="feature-link">Lihat detail <Icon name="arrowUpRight" size={14}/></Link>
        </div>
        <div className="playbook-feature panel home-guide-compact">
          <div className="eyebrow">PANDUAN / CATATAN</div>
          <h3>{playbooks[0].title}</h3>
          <Link href={`/playbook/${playbooks[0].slug}`} className="section-link">Baca panduan <Icon name="arrow" size={14}/></Link>
        </div>
      </section>

      <section className="home-pathway" aria-labelledby="home-pathway-heading">
        <h2 id="home-pathway-heading">Alur singkat</h2>
        <ol className="home-pathway-steps">
          {["Temukan", "Periksa", "Pilih", "Siapkan"].map((label, index) => (
            <li key={label}><span>{String(index + 1).padStart(2, "0")}</span><strong>{label}</strong></li>
          ))}
        </ol>
      </section>

      <section className="closing-cta home-closing-cta">
        <h2>Sudah menemukan lomba pilihanmu?</h2>
        <LinkButton href="/workspace" variant="dark">Buka Tersimpan <Icon name="arrow" size={15}/></LinkButton>
      </section>
    </div>
  );
}
